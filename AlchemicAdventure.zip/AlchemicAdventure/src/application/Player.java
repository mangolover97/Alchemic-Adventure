package application;

import java.io.File;
import java.util.ArrayList;
import javafx.animation.Animation;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.util.Duration;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Player
 * 
 * Subclass of the Character class. The user of the
 * program controlls an instance of this object.
 * This object can move in the x and y axis, as well as
 * collide with tiles and enemies.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class Player extends Character {
	
	//**************************************************************************
	//
	//	 							ATTRIBUTES
	//
	//**************************************************************************
	
	// graphics and animation attributes
	private ImageView imageView;
	private int facing = 1; // 1 = right, -1 = left
	private final int WALK_ANIMATION = 0;
	private final int JUMP_ANIMATION = 1;
	private final int STAND_ANIMATION = 2;

	// user input attributes

	private ArrayList<String> input = new ArrayList<String>();
	private boolean right;
	private boolean left;
	private boolean space;
	private boolean f;

	// movement attributes

	private final double MAX_SPEED = 7;
	private final double HORIZONTAL_ACCELERATION = 2;
	private final double JUMP_HEIGHT = 15;
	private boolean isGrounded;

	// HUD attributes
	
	private int lives = 3;
	private int potionTimer;
	
	//death boolean
	private boolean isDead;
	

	// **************************************************************************
	//
	// 								CONSTRUCTOR
	//
	// **************************************************************************

	public Player(GraphicsContext gc, Canvas canvas, double x, double y, ArrayList<String> input) {
		this.gc = gc;
		this.canvas = canvas;

		this.input = input;

		this.pos = new Vector(x, y);
		this.vel = new Vector(0, 0);
		this.accel = new Vector(0, GRAVITY);
		this.xsize = 50;
		this.ysize = 60;
		this.size = 60;

		this.hitBox = new Rectangle2D(this.pos.getX(), this.pos.getY(), this.xsize, this.ysize);

		this.image = new Image("resources/Sprites/Player/playerspritesheet.png");
		this.imageView = new ImageView(image);
		this.imageView.setScaleX(-1);
		this.imageView.setViewport(new Rectangle2D(0, this.size, this.size, this.size));
		this.imageView.setX(Main.SCREENWIDTH / 2 - this.size / 2);
		this.imageView.setY(Main.SCREENHEIGHT / 2 - this.size / 2);

		((AnchorPane) this.canvas.getParent()).getChildren().add(imageView);

		// ANIMATIONS

		this.animations.add(new SpriteAnimation(imageView, Duration.millis(500), 8, 8, 0, size, size, size));
		this.animations.add(new SpriteAnimation(imageView, Duration.millis(10), 2, 2, 0, size * 2, size, size));
		this.animations.add(new SpriteAnimation(imageView, Duration.millis(3000), 2, 2, 0, 0, size, size));

		for (Animation a : animations)
			a.setCycleCount(Animation.INDEFINITE);
		
	}

	// **************************************************************************
	//
	// 							PUBLIC METHODS
	//
	// **************************************************************************

	public void update() {
		// boolean variables for key press

		this.right = this.input.contains(KeyCode.RIGHT.toString());
		this.left = this.input.contains(KeyCode.LEFT.toString());
		this.space = this.input.contains(KeyCode.SPACE.toString());
		this.f = this.input.contains(KeyCode.F.toString());

		// move to new position
		move();

		// check player collision with tiles
		checkTileCollision();
		
		// reset player hitbox
		this.hitBox = new Rectangle2D(this.pos.getX(), this.pos.getY(), this.xsize, this.ysize);
		
		// check player collision with enemies
		checkEnemyCollision();
		
		// fire projectiles
		throwPotion();
		if (potionTimer > 0)
			this.potionTimer--;

		// animate
		playAnimations();
		
	}

	@Override
	public void draw() {
		update();
		this.imageView.setScaleX(this.facing);
	}

	// **************************************************************************
	//
	// 							PRIVATE METHODS
	//
	// **************************************************************************

	// method to deal with player movement

	private void move() {
		// left arrow movement acceleration

		if (this.left && !this.right) {
			this.accel.setX(HORIZONTAL_ACCELERATION * -1);
			this.facing = -1;
		}

		// right arrow movement acceleration

		else if (this.right && !this.left) {
			this.accel.setX(HORIZONTAL_ACCELERATION);
			this.facing = 1;
		}

		// create a deceleration due to friction

		else if (this.vel.getX() >= this.HORIZONTAL_ACCELERATION
				|| this.vel.getX() <= this.HORIZONTAL_ACCELERATION * -1) {
			this.accel.setX(this.HORIZONTAL_ACCELERATION * ((this.vel.getX() > 0) ? -1 : 1));
		}

		// stop the player horizontal movement

		else {
			this.vel.setX(0.0);
			this.accel.setX(0.0);
		}

		if (this.space && this.isGrounded) {
			this.isGrounded = false;
			this.vel.setY(-this.JUMP_HEIGHT - this.GRAVITY);
		}

		// if the magnitude of the velocity will be lower than MAXSPEED, add
		// acceleration to it

		if (Math.abs(this.vel.add(accel).getX()) < MAX_SPEED)
			this.vel = this.vel.add(accel);

		// if the magnitude of the velocity will be greater than the MAXSPEED, set it to
		// MAXSPEED

		else if (Math.abs(this.vel.add(accel).getX()) >= MAX_SPEED) {
			this.vel.setX(MAX_SPEED * ((this.vel.add(accel).getX() > 0) ? 1 : -1));
			this.vel.setY(this.vel.getY() + this.accel.getY());
		}

	}
	
	@Override
	protected boolean findCornerTiles(double x, double y) {
		// row and column indices for each side of the player
		
		int leftTile = (int) x / TileMap.TILESIZE;
		int rightTile = (int) (x + this.size - 1) / TileMap.TILESIZE ;
		int upTile = (int) y / TileMap.TILESIZE;
		int downTile = (int) (y + this.size - 1) / TileMap.TILESIZE;
			
		// local variables for what type of tile the player will be intersecting
			
		int tlNum = TileMap.map[upTile][leftTile];
		int trNum = TileMap.map[upTile][rightTile];
		int blNum = TileMap.map[downTile][leftTile];
		int brNum = TileMap.map[downTile][rightTile];
			
		// boolean values for if there is a tile for each corner of the player
		
		this.tl = TileMap.map[upTile][leftTile] != 0;
		this.tr = TileMap.map[upTile][rightTile] != 0;
		this.bl = TileMap.map[downTile][leftTile] != 0;
		this.br = TileMap.map[downTile][rightTile] != 0;
			
		if (tlNum == 3 || trNum == 3 || blNum == 3 || brNum == 3) {
			GameController.gsm.setState(GameController.gsm.getStateNum() + 1);
			// true if need to stop the collision method
			return true;
		}else if (tlNum == 4 || trNum == 4 || blNum == 4 || brNum == 4) {
			this.loseLife();
			return true;
		}
		return false;
	}
	
	// method dealing with collision detection with tiles

	private void checkTileCollision() {
		// local variables
		double x = this.pos.getX();
		double y = this.pos.getY();

		int currCol = (int) x / TileMap.TILESIZE;
		int currRow = (int) y / TileMap.TILESIZE;

		double newX = x + this.vel.getX();
		double newY = y + this.vel.getY();

		double tempX = x;
		double tempY = y;

		// ***************************************
		// ***************************************
		// CHECK FOR COLLISION IN THE Y AXIS
		// ***************************************
		// ***************************************

		if (findCornerTiles(x, newY))
			return;

		// check for collision when the player is moving up

		if (this.vel.getY() < 0) {
			if (this.tl || this.tr) {
				this.vel.setY(0);
				tempY = currRow * TileMap.TILESIZE;
			} else {
				tempY += this.vel.getY();
			}
		}

		// check for collision when the player is moving down

		if (this.vel.getY() > 0) {
			if (bl || br) {
				this.vel.setY(0);
				this.isGrounded = true;
				tempY = (currRow + 1) * TileMap.TILESIZE - this.size;
			} else {
				tempY += this.vel.getY();
			}
		}

		// ***************************************
		// ***************************************
		// CHECK FOR COLLISION IN THE X AXIS
		// ***************************************
		// ***************************************

		if (findCornerTiles(newX, y))
			return;

		// check for collision when player is moving left

		if (this.vel.getX() < 0) {
			if (tl || bl) {
				this.vel.setX(0);
				tempX = currCol * TileMap.TILESIZE;
			} else {
				tempX += this.vel.getX();
			}
		}

		// check for collision when player is moving right

		if (this.vel.getX() > 0) {
			if (tr || br) {
				this.vel.setX(0);
				tempX = (currCol + 1) * TileMap.TILESIZE - this.size;
			} else {
				tempX += this.vel.getX();
			}
		}

		// ******************************
		// ******************************
		// COLLISION ENDING
		// ******************************
		// ******************************

		// check if there is ground under player
		if (this.isGrounded) {
			findCornerTiles(x, newY + 1);
			if (!bl && !br) {
				isGrounded = false;
			}
		}

		// set player's position to the new position
		this.pos.setX(tempX);
		this.pos.setY(tempY);
	}
	
	// method to check player collision with enemy.
	
	private void checkEnemyCollision() {
		for (Enemy enemy : Enemy.enemyList) {
			if (enemy != null) {
				if (this.hitBox.intersects(enemy.getHitBox())) {
					this.loseLife();
					break;
				}
			}
		}
	}
	
	// method to make the player lose a life

	void loseLife() {
		this.lives--;
		GameController.gsm.setState(GameController.gsm.getStateNum());
		
		if (this.lives == 0 ) {
			this.isDead = true;
		}
	}

	// method for the player to throw a potion

	private void throwPotion() {
		if (this.f && this.potionTimer == 0) {
			Projectile.projectileList.add(new Projectile(this.gc, this.pos.getX() + this.size / 2, this.pos.getY() + this.size / 2,
					Math.abs(this.vel.getX()), this.facing));
			this.potionTimer = 60;
		}
	}

	// method to play animations
	
	protected void playAnimations() {
		// jump animation

		if (!this.isGrounded || this.space) {
			stopAnimations(animations.get(JUMP_ANIMATION));
			this.animations.get(JUMP_ANIMATION).play();
		}

		// left and right walking animation

		else if (this.left || this.right) {
			stopAnimations(animations.get(WALK_ANIMATION));
			this.animations.get(WALK_ANIMATION).play();
		}

		// standing animation

		else {
			stopAnimations(animations.get(STAND_ANIMATION));
			this.animations.get(STAND_ANIMATION).play();

		}
	}

	// method to stop all but one animation

	private void stopAnimations(Animation a) {
		for (Animation animation : this.animations) {
			if (!animation.equals(a)) {
				animation.stop();
			}
		}
	}

	// **************************************************************************
	//
	// 							GETTER AND SETTER METHODS
	//
	// **************************************************************************

	public ImageView getImageView() {
		return imageView;
	}

	public void setImageView(ImageView imageView) {
		this.imageView = imageView;
	}

	public int getLives() {
		return lives;
	}

	public void setLives(int lives) {
		this.lives = lives;
	}

	public int getPotionTimer() {
		return potionTimer;
	}

	public void setPotionTimer(int potionTimer) {
		this.potionTimer = potionTimer;
	}

	public boolean isDead() {
		return isDead;
	}
	
}
