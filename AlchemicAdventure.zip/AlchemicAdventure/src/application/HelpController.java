package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class HelpController {
	Scene gameScene;
	@FXML
	Canvas canvas;
	
	public void getScene(Stage primaryStage) {
		gameScene = primaryStage.getScene();
	}
	public void buttonClicked(ActionEvent evt) throws IOException {
		Button clicked = (Button) evt.getTarget();
		String label = clicked.getText();
		
		switch (label) {
		case "Menu":
			new SceneSwitcher(canvas.getGraphicsContext2D(), canvas, gameScene, "Menu.fxml").animate();
			break;
		}
	}
}
