package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: VictoryController
 * 
 * The controller class for the Victory.fxml file.
 * Handles all button clicks for the JavaFX Scene.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class VictoryController{
	
	//**************************************************************************
	//
	//	 							OBJECTS
	//
	//**************************************************************************
	
	@FXML
	Canvas victoryCanvas;
	GraphicsContext gc;
	Scene gameScene;
	
	static Label score;
	
	//**************************************************************************
	//
	//	 								METHODS
	//
	//**************************************************************************
	
	// method to get the current scene
	
	public void getScene(Stage primaryStage) {
		gameScene = primaryStage.getScene();
	}
	
	// method to handle all button clicks
	
	public void buttonClicked(ActionEvent evt) throws IOException {
		Button clicked = (Button) evt.getTarget();
		String label = clicked.getText();
		
		switch (label) {
		case "Menu":
			new SceneSwitcher(gc, victoryCanvas, gameScene).switchScene("Menu.fxml");
			break;
		}
	}
	public void setScore(GameStateManager gsm) {
		score = new Label("Score: " + (150 * 4 - (int) Math.round(gsm.getPassedTime() / Math.pow(10, 9))));
		Font font = Font.font("Connection III", 40);
		score.setFont(font);
		score.setTextFill(Color.CRIMSON);
		BorderPane root = (BorderPane)gameScene.getRoot();
		((VBox) ((AnchorPane)root.getChildren().get(0)).getChildren().get(0)).getChildren().add(score);
		score.toFront();
		
	}
}

