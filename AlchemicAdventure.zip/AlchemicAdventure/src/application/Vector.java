package application;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Vector
 * 
 * A class representing a mathematic vector. There are
 * methods allowing for easy vector manipulation.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class Vector {
	//**************************************************************************
	//
	//	 							ATTRIBUTES
	//
	//**************************************************************************
	
	private double x;
	private double y;
	
	//**************************************************************************
	//
	//	 							CONSTRUCTOR
	//
	//**************************************************************************
	
	public Vector(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	//**************************************************************************
	//
	//	 							METHODS
	//
	//**************************************************************************
	
	public Vector add(Vector v) {
		return new Vector(this.x + v.getX(), this.y + v.getY());
	}
	
	//**************************************************************************
	//
	//	 						GETTERS AND SETTERS
	//
	//**************************************************************************
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	
	
	
}
