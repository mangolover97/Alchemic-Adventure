package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: TileMap
 * 
 * The class that handles the map of the game. Depending
 * in the current GameState, the map will be different.
 * Each Character can interact with the map.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class TileMap {
	//**************************************************************************
	//
	// 								ATTRIBUTES
	//
	//**************************************************************************
	
	private GraphicsContext gc;
	
	static int[][] map;
	
	public static final int TILESIZE = 80;
	private String tileSet;
	private Image tiles;
	
	private int numTilesAcross;
	
	private int numCols, numRows;
	private int width, height;

	//**************************************************************************
	//
	// 								CONSTRUCTOR
	//
	//**************************************************************************
	
	public TileMap(GraphicsContext gc) {
		this.gc = gc;
	}
	
	//**************************************************************************
	//
	// 								METHODS
	//
	//**************************************************************************
	
	// method to draw the tiles
	
	public void draw() {
		for (int row = 0 ; row < this.numRows ; row++) {
			for (int col = 0 ; col < this.numCols ; col++) {
				// draw the tile in the proper position and as the right sprite from
				// the sprite sheet
				gc.drawImage(tiles,
						TileMap.TILESIZE * (TileMap.map[row][col] % TileMap.TILESIZE), 
						TileMap.TILESIZE * (TileMap.map[row][col] / TileMap.TILESIZE), 
						TileMap.TILESIZE, 
						TileMap.TILESIZE,
						col * TileMap.TILESIZE,
						row * TileMap.TILESIZE,
						TileMap.TILESIZE,
						TileMap.TILESIZE
						);
			}
		}
	}
	
	// method to set the map attribute to a loaded file
	
	public void loadMap(String path) {
		try {
			// create BufferedReader object to read from file
			BufferedReader br = new BufferedReader(new FileReader(path));
			
			this.numCols = Integer.parseInt(br.readLine());
			this.numRows = Integer.parseInt(br.readLine());
			
			TileMap.map = new int[numRows][numCols];
			this.width = this.numCols * TileMap.TILESIZE;
			this.height = this.numRows * TileMap.TILESIZE;
			
			// fill in the map from the txt file
			for (int row = 0; row < this.numRows ; row++) {
				String line = br.readLine();
				String[] nums = line.split("\\s+");
				for (int col = 0 ; col < numCols ; col++) {
					TileMap.map[row][col] = Integer.parseInt(nums[col]);
				}
			}
			br.close();
			
		}catch(Exception e) {}
	}
	
	// method to set the tiles attribute to a loaded file
	
	public void loadTiles(String path) {
		this.tiles = new Image(path);
		this.numTilesAcross = (int) this.tiles.getWidth() / TileMap.TILESIZE;
	}
}
