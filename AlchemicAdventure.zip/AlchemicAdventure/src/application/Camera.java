package application;

import java.util.ArrayList;
import javafx.scene.canvas.Canvas;
import javafx.scene.input.KeyCode;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Camera
 * 
 * A class that can be instantiated. An object of this class
 * represents the camera. The camera is designed to center the
 * screen on the player, while moving everything else to show movement.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class Camera {
	
	//**************************************************************************
	//
	// 								ATTRIBUTES
	//
	//**************************************************************************
	
	private double x;
	private double y;
	private ArrayList<String> input;
	private int upCounter = 0;
	private int downCounter = 0;
	
	// constant to multiply the background's translation,
	// simulates a far-away effect
	public final static double BGSCALE = 0.1;
	
	//**************************************************************************
	//
	// 								CONSTRUCTOR
	//
	//**************************************************************************
	
	// camera constructor
	
	public Camera(double x, double y, ArrayList<String> input) {
		this.x = x;
		this.y = y;
		this.input = input;
	}
	
	//**************************************************************************
	//
	// 								METHODS
	//
	//**************************************************************************
	
	public void update(Player player) {
		// booleans for user input
		boolean up = input.contains(KeyCode.UP.toString());
		boolean down = input.contains(KeyCode.DOWN.toString());
		
		// set the position of the camera
		this.x = -player.getPos().getX() - player.getSize() / 2 + Main.SCREENWIDTH / 2;
		this.y = -player.getPos().getY() - player.getSize() / 2 + Main.SCREENHEIGHT / 2;
		
		// look up counter
		if (up && !down) {
			upCounter++;
		}else
			upCounter = 0;
		
		// look down counter
		if (down && !up) {
			downCounter ++;
		}else
			downCounter = 0;
		
		// look up
		
		if (upCounter >= 60) {
			upCounter = 60;
			this.y += (Main.SCREENHEIGHT / 2 - player.size / 2);
			GameController.bg.setTranslate(0, (Main.SCREENHEIGHT / 2 - player.size / 2));
			player.getImageView().setY(Main.SCREENHEIGHT - player.size);
		}
		
		// look down
		
		else if (downCounter >= 60) {
			this.y -= (Main.SCREENHEIGHT / 2 - player.getSize() / 2 );
			GameController.bg.setTranslate(0, -(Main.SCREENHEIGHT / 2 - player.getSize() / 2));
			player.getImageView().setY(0);
		}
		
		// look neutral
		
		else{
			GameController.bg.setTranslate(0, 0);
			player.getImageView().setY(Main.SCREENHEIGHT / 2 - player.getSize() / 2);
		}
	}
	
	//**************************************************************************
	//
	// 							GETTERS AND SETTERS
	//
	//**************************************************************************
	
	public double getX() {return this.x;}
	public void setX(double x) {this.x = x;}
	public double getY() {return this.y;}
	public void setY(double y) {this.y = y;}
}
