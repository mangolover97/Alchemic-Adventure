package application;

import java.util.ArrayList;
import javafx.animation.Animation;
import javafx.fxml.FXML;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Enemy
 * 
 * A subclass to the Character class. Each object represents
 * an enemy in the map. When the player contacts an enemy,
 * the player will lose a life
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class Enemy extends Character{

	//**************************************************************************
	//
	//	 							ATTRIBUTES
	//
	//**************************************************************************
	
	static ArrayList<Enemy> enemyList = new ArrayList<Enemy>();
	private int index;
	
	ImageView imageView;
	
	//**************************************************************************
	//
	//	 							CONSTRUCTOR
	//
	//**************************************************************************
	
	public Enemy(GraphicsContext gc, Canvas canvas, double x, double y, double dx, double dy) {
		this.gc = gc;
		this.canvas = canvas;
		
		this.index = enemyList.size();
		
		this.image = new Image("resources/Sprites/Enemies/arachnik.gif");
		this.imageView = new ImageView(this.image);
		((AnchorPane) this.canvas.getParent()).getChildren().add(imageView);
		this.size = (int) this.image.getHeight();
		
		this.pos = new Vector(x, y - this.size);
		this.vel = new Vector(dx, dy);
		this.accel = new Vector(0, 0);
		
		this.hitBox = new Rectangle2D(this.pos.getX(), this.pos.getY(), this.size, this.size);
		
		this.animations.add(new SpriteAnimation(imageView, Duration.millis(500), 2, 2, 0, 0, size, size));
		animations.get(0).setCycleCount(Animation.INDEFINITE);
	}
	
	//**************************************************************************
	//
	//	 								METHODS
	//
	//**************************************************************************
	
	// update method for Enemy, deals with movement and collision attributes
	
	@Override
	protected void update() {
		this.pos = this.pos.add(this.vel);
		this.vel = this.vel.add(this.accel);
		this.hitBox = new Rectangle2D(this.pos.getX(), this.pos.getY(), this.size, this.size);
		
		findCornerTiles(this.pos.getX(), this.pos.getY() + 1);
		if (!br || !bl) {
			this.vel.setX(-this.vel.getX());
		}
	}
	
	// draw method for Enemy, deals with drawing the object to the screen (or not).
	
	@Override
	protected void draw() {
		update();
		this.imageView.setX(this.pos.getX());
		this.imageView.setY(this.pos.getY());
		playAnimations();
	}
	
	// method to play the Enemy's animation.
	
	@Override
	protected void playAnimations() {
		animations.get(0).play();
	}
	
	// method to set the imageView to invisible
	
	public void setVisible(boolean v) {
		this.imageView.setVisible(v);
	}
	
	// getter method for returning this instance's index in the enemyList
	
	public int getIndex() {
		return this.index;
	}
}
