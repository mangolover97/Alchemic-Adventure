package application;

import java.util.ArrayList;

import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Projectile
 * 
 * Subclass of the Character class. The player can
 * create instances of this class, and each instance
 * can interact with the environment. On intersection
 * with an enemy, the enemy is removed.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class Projectile extends Character{
	
	//**************************************************************************
	//
	//	 							ATTRIBUTES
	//
	//**************************************************************************	
	
	// STATIC ARRAYLIST CONTAINING ALL OF THE PROJECTILES
	
	static ArrayList<Projectile> projectileList = new ArrayList<Projectile>();
	
	// index of the object in the projectileList
	private int index;
	
	private double PROJECTILE_SPEED = 7;
	
	//**************************************************************************
	//
	//	 							CONSTRUCTOR
	//
	//**************************************************************************
	
	public Projectile (GraphicsContext gc, double x, double y, double dx, int facing) {
		this.gc = gc;
		this.index = projectileList.size();
		
		this.pos = new Vector(x, y);
		this.vel = new Vector((PROJECTILE_SPEED + dx) * facing, -15);
		this.accel = new Vector(0, GRAVITY);
		
		this.image = new Image("resources/Sprites/Player/potion.png");
		
		this.size = (int)this.image.getHeight();
		this.hitBox = new Rectangle2D(this.pos.getX(), this.pos.getY(), this.size, this.size);
		
	}
	
	//**************************************************************************
	//
	//	 							METHODS
	//
	//**************************************************************************
	
	// method to update the projectile
	
	@Override
	public void update() {
		// change the position and velocity of the projectile
		this.pos = this.pos.add(vel);
		this.vel = this.vel.add(this.accel);
		this.hitBox = new Rectangle2D(this.pos.getX(), this.pos.getY(), this.size, this.size);
		
		// check for collisions with tiles
		
		this.findCornerTiles(this.pos.getX(), this.pos.getY());
		if (tl || tr || br || bl) {
			projectileList.set(index, null);
		}
		
		// check for collision with enemies
		
		for (Enemy enemy : Enemy.enemyList) {
			if (enemy != null) {
				if (this.hitBox.intersects(enemy.getHitBox())) {
					enemy.setVisible(false);
					Enemy.enemyList.set(enemy.getIndex(), null);
					projectileList.set(index, null);
				}
			}
		}
	}
	
	// method to draw the projectile
	
	@Override
	public void draw() {
		update();
		if (this != null) {
			gc.drawImage(this.image, this.pos.getX(), this.pos.getY());
		}
	}
	
	// empty method for playing animations (no animation)
	
	protected void playAnimations() {}
}
