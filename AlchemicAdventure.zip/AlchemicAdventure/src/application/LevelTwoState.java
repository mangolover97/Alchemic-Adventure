package application;

import javafx.scene.canvas.Canvas;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: LevelOneState
 * 
 * Subclass of the GameState class. This GameState
 * represents the second level.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class LevelTwoState extends GameState {
	GameStateManager gsm;
	
	//**************************************************************************
	//
	//	 							CONSTRUCTOR
	//
	//**************************************************************************
	
	// set attributes
	
	public LevelTwoState(GameStateManager gsm, Canvas canvas) {
		super(gsm, canvas);
		this.startingTile[0] = 9;
		this.startingTile[1] = 19;
		
		this.mapPath = "src/resources/Maps/level2.txt";
		
		this.levelTime = 60;
		
		this.enemyLocations.add(new Integer[] {21, 18});
		this.enemyLocations.add(new Integer[] {23, 18});
		this.enemyLocations.add(new Integer[] {25, 17});
		this.enemyLocations.add(new Integer[] {44, 18});
		this.enemyLocations.add(new Integer[] {46, 18});
		this.enemyLocations.add(new Integer[] {48, 18});
	}
}
