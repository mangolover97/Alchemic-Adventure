package application;

import java.util.ArrayList;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: GameStateManager
 * 
 * GameStateManager class handles all of the GameStates,
 * allowing to switch between and use GameStates.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class GameStateManager {

	// **************************************************************************
	//
	// 								ATTRIBUTES
	//
	// **************************************************************************

	private ArrayList<GameState> gameStates;
	private int currentState;
	private Canvas canvas;
	private Scene gameScene;

	// timer for levels
	private long time;
	private long passedTime;

	// constants
	public static final int LEVEL_ONE_STATE = 0;
	public static final int VICTORY_STATE = 2;

	// **************************************************************************
	//
	// 								CONSTRUCTOR
	//
	// **************************************************************************
	public GameStateManager(Canvas canvas, Scene gameScene) {
		this.canvas = canvas;
		this.gameScene = gameScene;
		this.time = System.nanoTime();
		gameStates = new ArrayList<GameState>();

		// set the current state to level one
		currentState = LEVEL_ONE_STATE;

		// add states to the gameStates list
		gameStates.add(new LevelOneState(this, this.canvas));
		gameStates.add(new LevelTwoState(this, this.canvas));

		gameStates.get(LEVEL_ONE_STATE).init();
	}

	// **************************************************************************
	//
	// 							GETTERS AND SETTERS
	//
	// **************************************************************************

	public void setState(int state) {
		this.passedTime += gameStates.get(currentState).getPassedTime();
		currentState = state;
		if (currentState >= VICTORY_STATE) {
			new SceneSwitcher(GameController.gc, canvas, gameScene, "Victory.fxml", this).animate();
		} else {
			gameStates.get(currentState).init();
		}
	}

	public void setTime(long time) {
		this.time = time;
	}

	public long getTime() {
		return this.time;
	}

	public GameState getState() {
		return gameStates.get(currentState);
	}

	public int getStateNum() {
		return currentState;
	}

	public long getPassedTime() {
		return passedTime;
	}

	public void setPassedTime(long passedTime) {
		this.passedTime = passedTime;
	}

}
