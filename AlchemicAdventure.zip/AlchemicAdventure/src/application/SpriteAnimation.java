package application;

import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: SpriteAnimation
 * 
 * A class that deals with animation. Each instance
 * of this class represents a different animation. 
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class SpriteAnimation extends Transition {

	//**************************************************************************
	//
	//	 							ATTRIBUTES
	//
	//**************************************************************************
	
    private final ImageView imageView;
    
    // amount of frames in the animation
    private final int count;
    
    private final int columns;
    
    // start position of the animation in the sprite sheet
    private final int offsetX;
    private final int offsetY;
    private final int width;
    private final int height;

    private int lastIndex;

    //**************************************************************************
    //
    //     							CONSTRUCTOR
    //
    //**************************************************************************
    
    public SpriteAnimation(
            ImageView imageView, 
            Duration duration,
            int count, int columns,
            int offsetX, int offsetY,
            int width,   int height) {
        this.imageView = imageView;
        this.count     = count;
        this.columns   = columns;
        this.offsetX   = offsetX;
        this.offsetY   = offsetY;
        this.width     = width;
        this.height    = height;
        setCycleDuration(duration);
        setInterpolator(Interpolator.LINEAR);
    }
    
    //**************************************************************************
    //
    //     						INTERPOLATE METHOD
    //
    //**************************************************************************
    
    // method that is automatically called to set the parameters of the animation.
    
	protected void interpolate(double k) {
		// geometrically create the animation
		
        final int index = Math.min((int)(k * count), count - 1);
        if (index != lastIndex) {
            final int x = (index % columns) * width  + offsetX;
            final int y = (index / columns) * height + offsetY;
            
            // set the current frame of the animation
            imageView.setViewport(new Rectangle2D(x, y, width, height));
            
            lastIndex = index;
        }
    }
}