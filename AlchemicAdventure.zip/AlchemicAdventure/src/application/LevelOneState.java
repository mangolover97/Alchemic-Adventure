package application;

import javafx.scene.canvas.Canvas;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: LevelOneState
 * 
 * Subclass of the GameState class. This GameState
 * represents the first level.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class LevelOneState extends GameState {
	
	// GameStateManager object
	GameStateManager gsm;
	
	
	//**************************************************************************
	//
	//	 							CONSTRUCTOR
	//
	//**************************************************************************
	
	// set attributes
	
	public LevelOneState(GameStateManager gsm, Canvas canvas) {
		super(gsm, canvas);
		this.startingTile[0] = 9;
		this.startingTile[1] = 19;
		
		this.mapPath = "src/resources/Maps/level1.txt";
		
		this.levelTime = 90;
		
		this.enemyLocations.add(new Integer[] {34, 19});
		this.enemyLocations.add(new Integer[] {35, 19});
	}
}
