package application;

import java.util.ArrayList;

import javafx.animation.Animation;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Character
 * 
 * An abstract class designed for all entities on the screen.
 * This class comes with attributes describing each subclass object.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public abstract class Character{
	//**************************************************************************
	//
	// 								ATTRIBUTES
	//
	//**************************************************************************
	protected Canvas canvas;
	protected GraphicsContext gc;
	
	// movement attributes
	
	protected Vector pos;
	protected Vector vel;
	protected Vector accel;
	
	protected final double GRAVITY = 1.25;
	
	// graphics attributes
	
	protected Image image;
	protected ArrayList<Animation> animations = new ArrayList<Animation>();
	
	// collision detection attributes
	
	protected Rectangle2D hitBox;
	protected int size;
	protected int xsize;
	protected int ysize;
	
	protected boolean tl, tr, bl, br;
	
	//**************************************************************************
	//
	// 								METHODS
	//
	//**************************************************************************
	
	// method to update the Character
	
	protected abstract void update();
	
	// method to play the animations of the Character
	
	protected abstract void playAnimations();
	
	// method to draw the Character
	
	protected void draw() {
		this.gc.drawImage(this.image, this.pos.getX(), this.pos.getY());
		update();
	}
	
	// method to find the corners of the player at given x and y
	
	protected boolean findCornerTiles(double x, double y) {
		// row and column indices for each side of the player
		
		int leftTile = (int) x / TileMap.TILESIZE;
		int rightTile = (int) (x + this.size - 1) / TileMap.TILESIZE;
		int upTile = (int) y / TileMap.TILESIZE;
		int downTile = (int) (y + this.size - 1) / TileMap.TILESIZE;
			
		// local variables for what type of tile the player will be intersecting
			
		int tlNum = TileMap.map[upTile][leftTile];
		int trNum = TileMap.map[upTile][rightTile];
		int blNum = TileMap.map[downTile][leftTile];
		int brNum = TileMap.map[downTile][rightTile];
			
		// boolean values for if there is a tile for each corner of the player
		
		this.tl = TileMap.map[upTile][leftTile] != 0;
		this.tr = TileMap.map[upTile][rightTile] != 0;
		this.bl = TileMap.map[downTile][leftTile] != 0;
		this.br = TileMap.map[downTile][rightTile] != 0;
			
		if ((tlNum == 3 || trNum == 3 || blNum == 3 || brNum == 3) && this instanceof Player) {
			GameController.gsm.setState(GameController.gsm.getStateNum() + 1);
			// true if need to stop the collision method
			return true;
		}
		return false;
	}
	
	//**************************************************************************
	//
	// 								GETTERS AND SETTERS
	//
	//**************************************************************************
	
	public Rectangle2D getHitBox(){return hitBox;}
	public Vector getPos() {return pos;}
	public void setPos(Vector pos) {this.pos = pos;}
	public Vector getVel() {return vel;}
	public void setVel(Vector vel) {this.vel = vel;}
	public Image getImage() {return image;}
	public void setImage(Image image) {this.image = image;}
	public int getSize() {return size;}
	public void setSize(int size) {this.size = size;}
}
