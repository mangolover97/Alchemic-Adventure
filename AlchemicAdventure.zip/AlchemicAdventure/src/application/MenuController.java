package application;

import java.io.IOException;

import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: MenuController
 * 
 * Controller class to the Menu.fxml file. Deals
 * with all button presses in the scene.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class MenuController {
	
	//**************************************************************************
	//
	//	 					OBJECTS AND ATTRIBUTES
	//
	//**************************************************************************

	@FXML
	Canvas menuCanvas;
	GraphicsContext gc;
	Scene gameScene;
	
	// boolean value for if the window is being swapped
	boolean swapped;
	
	//**************************************************************************
	//
	//	 							METHODS
	//
	//**************************************************************************
	
	// method to handle button clicks
	
	public void buttonClicked(ActionEvent evt) throws IOException {
		Button clicked = (Button) evt.getTarget();
		String label = clicked.getText();
		
		switch (label) {
		case "Play":
			new SceneSwitcher(gc, menuCanvas, gameScene, "Game.fxml").animate();
			swapped = true;
			break;
		case "Help":
			new SceneSwitcher(gc, menuCanvas, gameScene, "Help.fxml").animate();
			break;
		
		case "Quit":
			Platform.exit();
			break;
		}
	}
	
	// method to get the current scene
	
	public void getScene(Stage primaryStage) {
		gameScene = primaryStage.getScene();
	}

	// method to start the loop that runs the background animation for the menu canvas
	
	public void menuLoop() {
		swapped = false;
		// create graphics context object
		gc = menuCanvas.getGraphicsContext2D();

		// create background image object
		Background b = new Background(gc, menuCanvas, new Image("resources/Backgrounds/menubg.png"), 1, 0, 0);


		new AnimationTimer() {
			// actual game loop that repeats
			@Override
			public void handle(long currentNanoTime) {
				gc.fillRect(0, 0, menuCanvas.getWidth(), menuCanvas.getHeight());
				b.draw();
				if (swapped) stop();
			}
		}.start();
	}

}