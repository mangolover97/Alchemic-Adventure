package application;

import java.util.ArrayList;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: GameState
 * 
 * An abstract class designed for each game state. 
 * Game states are similar to levels, in that each
 * game state contains layout properties for the map.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public abstract class GameState {
	//**************************************************************************
	//
	//	 							ATTRIBUTES
	//
	//**************************************************************************

	protected GameStateManager gsm;
	protected GraphicsContext gc = GameController.gc;
	protected Canvas canvas;

	Player player = GameController.player;
	TileMap tileMap = GameController.tileMap;

	protected int[] startingTile = new int[2];
	protected Vector startingPos;
	protected ArrayList<Integer[]> enemyLocations = new ArrayList<Integer[]>();
	
	protected long endTime;
	protected int levelTime;

	protected String mapPath;

	//**************************************************************************
	//
	//	 							CONSTRUCTOR
	//
	//**************************************************************************
	
	public GameState(GameStateManager gsm, Canvas canvas) {
		this.gsm = gsm;
		this.canvas = canvas;
	}
	
	//**************************************************************************
	//
	//	 							METHODS
	//
	//**************************************************************************
	
	// initialization method for the GameState
	
	public void init() {
		//timer 
		this.endTime = (long) (gsm.getTime() + Math.pow(10, 9) * this.levelTime);
		
		// clear all enemies
		for (Enemy enemy : Enemy.enemyList) {
			if (enemy != null)
				enemy.setVisible(false);
			enemy = null;
		}
		Enemy.enemyList.clear();
		
		// clear all projectiles
		
		Projectile.projectileList.clear();
		
		// set player position
		this.startingPos = new Vector(startingTile[0] * TileMap.TILESIZE + ((TileMap.TILESIZE - player.getSize()) / 2),
				startingTile[1] * TileMap.TILESIZE + (TileMap.TILESIZE - player.getSize()));
		player.setPos(startingPos);
		
		// load map
		tileMap.loadMap(mapPath);
		tileMap.loadTiles("/resources/Tilesets/grasstileset.gif");
		
		// set enemy locations
		for (Integer[] i : enemyLocations) {
			Enemy.enemyList.add(new Enemy(this.gc, this.canvas, i[0] * TileMap.TILESIZE, (i[1] + 1) * TileMap.TILESIZE, 5, 0));
		}
	}
	
	//**************************************************************************
	//
	//	 						GETTERS AND SETTERS
	//
	//**************************************************************************
	
	public int[] getStartingTile() {return startingTile;}
	public void setStartingTile(int[] startingTile) {this.startingTile = startingTile;}
	public Vector getStartingPos() {return startingPos;}
	public void setStartingPos(Vector startingPos) {this.startingPos = startingPos;}
	public long getEndTime() {return endTime;}
	public void setEndTime(long endTime) {this.endTime = endTime;}
	public long getPassedTime() {return (long)(levelTime * Math.pow(10, 9) - (endTime - gsm.getTime()));}
	

}
