package application;

import java.net.URL;
//import java.io.File;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
//import javafx.scene.media.Media;
//import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: GameController
 * 
 * Controller class to the Game.fxml file. This file
 * contains useful methods, but of the methods, the most
 * important is the gameLoop() method. This method is run 
 * for the duration of the time the player is in the "game" 
 * state.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class GameController implements Initializable{
	
	//**************************************************************************
	//
	// 								OBJECTS
	//
	//**************************************************************************
	
	@FXML 
	private Canvas gameCanvas;
	static GraphicsContext gc;
	private Scene gameScene;
	
	static Player player;
	private Camera cam;
	static TileMap tileMap;
	static Background bg;
	static GameStateManager gsm;
	
	// timer
	private long time;
	private Font timeFont;
	
	// audio (DOES NOT WORK)
	//private String MUSIC_PATH = "resources/Audio/music.mp3";
	//private Media music = new Media (new File(MUSIC_PATH).toURI().toString());
	//private MediaPlayer musicPlayer = new MediaPlayer(music);
	
	//**************************************************************************
	//
	// 								HUD CONSTANTS
	//
	//**************************************************************************
	
	private final int HUD_MARGIN = 20;
	private final int[] HEART_POS = {0, 0};
	private final int HEART_SIZE = 38;
	private final String HEART_PATH = "resources/HUD/heart.png";
	
	private final int[] POTION_POS = {0, HEART_SIZE};
	private final int POTION_SIZE = 38;
	private final String POTION_PATH = "resources/HUD/potion.png";
	
	//**************************************************************************
	//
	// 								METHODS
	//
	//**************************************************************************
	
	// method to set the scene
	
	public void getScene(Stage primaryStage) {
		gameScene = primaryStage.getScene();
	}
	
	
	// method to initialize the game
	
	private void init() {
		//musicPlayer.play();
		
		gc = gameCanvas.getGraphicsContext2D();
		
		ArrayList<String> input = new ArrayList<String>();
		
		// add pressed keys to ArrayList input
		gameScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent e) {
				String code = e.getCode().toString();
				if (!input.contains(code))
					input.add(code);
			}
		});
		
		// remove released keys from ArrayList input
		gameScene.setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent e) {
				String code = e.getCode().toString();
				if (input.contains(code))
					input.remove(code);
			}
		});
		
		// initialize objects
		player = new Player(gc, gameCanvas, 10 * TileMap.TILESIZE, 15 * TileMap.TILESIZE, input);
		cam = new Camera(0, 0, input);
		tileMap = new TileMap(gc);
		bg = new Background(gc, gameCanvas,new Image("/resources/Backgrounds/grassbg1.gif"), 10, 0, 0);
		gsm = new GameStateManager(gameCanvas, gameScene);
		
		timeFont = Font.font("Connection III", 40);
	}
	
	// method to update all objects on the screen
	
	private void update() {
		time = gsm.getTime();
		bg.setVector(-player.getVel().getX(), -player.getVel().getY());
		cam.update(player);
	}
	
	// method to draw the screen
	
	private void draw() {
		update();
		
		// START CAMERA BACKGROUND TRANSLATE
		gc.translate(cam.getX() * Camera.BGSCALE, cam.getY() * Camera.BGSCALE); 
		
		bg.draw();
		
		// END CAMERA BACKGROUND TRANSLATE
		gc.translate(-cam.getX() * Camera.BGSCALE, -cam.getY() * Camera.BGSCALE); 
		
		
		// START CAMERA TRANSLATE FOR EVERYTHING BUT BACKGROUND
		gc.translate(cam.getX(), cam.getY());
		
		tileMap.draw();
		
		// draw projectiles
		int counter = 0;
		for (Projectile p : Projectile.projectileList) {
			if (p != null) 
				p.draw();
			else 
				counter++;
		}
		// if list of null values, clear it
		if (counter == Projectile.projectileList.size()) 
			Projectile.projectileList.clear();
		
		// draw enemies
		counter = 0;
		for (Enemy enemy : Enemy.enemyList) {
			if (enemy != null) {
				enemy.imageView.setTranslateX(cam.getX());
				enemy.imageView.setTranslateY(cam.getY());
				enemy.draw();
			}
			else
				counter++;
		}
		// if list of null valuse, clear it
		if (counter == Enemy.enemyList.size()) 
			Enemy.enemyList.clear();
		
		// END CAMERA TRANSLATE FOR EVERYTHING BUT BACKGROUND
		gc.translate(-cam.getX(), -cam.getY()); 
		
		drawHUD();
		player.draw();
		
	}
	
	// method to draw heads up display (HUD)
	
	private void drawHUD() {
		// draw lives
		for (int i = 0 ; i < player.getLives() ; i++)
			gc.drawImage(new Image(HEART_PATH), HEART_POS[0] + HUD_MARGIN + HEART_SIZE * i, HEART_POS[0] + HUD_MARGIN);
		
		// draw potion cooldown
		
		double potionOffset = POTION_SIZE - POTION_SIZE * (60 - player.getPotionTimer()) / 60;
		//gc.fillRect(0, POTION_SIZE, POTION_SIZE, potionOffset);
		gc.drawImage(new Image(POTION_PATH), 0,
				potionOffset,
				POTION_SIZE, POTION_SIZE - potionOffset,
				POTION_POS[0] + HUD_MARGIN, POTION_POS[1] + 2*HUD_MARGIN + potionOffset, POTION_SIZE, POTION_SIZE - potionOffset);
		
		// draw time
		long timeRemaining = gsm.getState().getEndTime() - time;
		if (timeRemaining < 0) {
			player.setLives(1);
			player.loseLife();
		}
		
		int mins = (int)( timeRemaining / (Math.pow(10, 9) * 60));
		timeRemaining %= (Math.pow(10, 9) * 60);
		int secs = (int)(timeRemaining / (Math.pow(10, 9)));
		
		String txtString = "Time   -   " + ((mins > 0) ? mins + ": " : "") + String.format("%02d", secs);
		Text txt = new Text(txtString);
		txt.setFont(timeFont);
		
		gc.setFont(timeFont);
		gc.fillText(txtString, Main.SCREENWIDTH - txt.getLayoutBounds().getWidth() - HUD_MARGIN, 
				HUD_MARGIN + txt.getLayoutBounds().getHeight());
	}
	
	//**************************************************************************
	//
	// 								GAME LOOP
	//
	//**************************************************************************
	
	// method to run the game loop, this method is called once, and will run for
	// the duration of the program.
	
	public void gameLoop() {
		// run once
		init();
		
		// Animation timer to loop at a fixed frame rate
		new AnimationTimer() {
			@Override
			public void handle(long currentNanoTime) {
				gsm.setTime(currentNanoTime);
				draw();
				
				// go to end screen
				if (player.isDead()) {
					new SceneSwitcher(gc, gameCanvas, gameScene, "End.fxml").animate();
					stop();
				}else if (gsm.getStateNum() >= GameStateManager.VICTORY_STATE) {
					stop();
				}
			}
		}.start();
	}


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
	}
	
}
