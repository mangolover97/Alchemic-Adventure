package application;

import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: EndController
 * 
 * A class that is used as the controller to the End.fxml file.
 * this class deals with all button clicks in the end scene.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class EndController {
	//**************************************************************************
	//
	//	 							OBJECTS
	//
	//**************************************************************************
	
	@FXML
	Canvas endCanvas;
	GraphicsContext gc;
	Scene gameScene;
	
	//**************************************************************************
	//
	//	 							METHODS
	//
	//**************************************************************************
	
	// method to get the current scene
	
	public void getScene(Stage primaryStage) {
		gameScene = primaryStage.getScene();
	}
	
	// method to handle button clicks
	
	public void buttonClicked(ActionEvent evt) throws IOException {
		Button clicked = (Button) evt.getTarget();
		String label = clicked.getText();
		
		// switch case for button labels
		
		switch (label) {
		
		case "Play Again":
			new SceneSwitcher(gc, endCanvas, gameScene).switchScene("Menu.fxml");
			break;
			
		case "Quit":
			Platform.exit();
			break;
		}
	}
}
