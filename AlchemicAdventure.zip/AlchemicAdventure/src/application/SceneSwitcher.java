package application;

import java.io.IOException;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: SceneSwitcher
 * 
 * A class used to switch between JavaFX Scenes.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class SceneSwitcher {
	
	//**************************************************************************
	//
	// 								ATTRIBUTES
	//
	//**************************************************************************
	
	private GraphicsContext gc;
	private Canvas canvas;
	private Scene currentScene;
	private String newScene;
	
	// represents the transition rectangle's alpha (100 is opaque)
	int alpha = 0;
	private GameStateManager gsm;
	
	
	//**************************************************************************
	//
	// 								CONSTRUCTORS
	//
	//**************************************************************************
	
	// 
	public SceneSwitcher(GraphicsContext gc, Canvas canvas, Scene currentScene) {
		this.gc = gc;
		this.canvas = canvas;
		this.currentScene = currentScene;
	}
	
	public SceneSwitcher(GraphicsContext gc, Canvas canvas, Scene currentScene, String newScene) {
		this.gc = gc;
		this.canvas = canvas;
		this.currentScene = currentScene;
		this.newScene = newScene;
	}
	public SceneSwitcher(GraphicsContext gc, Canvas canvas, Scene currentScene, String newScene, GameStateManager gsm) {
		this.gc = gc;
		this.canvas = canvas;
		this.currentScene = currentScene;
		this.newScene = newScene;
		this.gsm = gsm;
	}
	
	//**************************************************************************
	//
	// 								METHODS
	//
	//**************************************************************************
	
	// method to switch the current scene to the new scene
	
	public void switchScene(String file) throws IOException{
		
		FXMLLoader loader = new FXMLLoader();   // we need access to the loader
        loader.setLocation(getClass().getResource(file));  
        BorderPane newSceneParent = (BorderPane)loader.load();
        
        Scene newScene = new Scene(newSceneParent,1280,720);
        
        // get stage information (this is the currently active stage
	    // the stage where the button press originated. 
        Stage stage = (Stage)currentScene.getWindow();
        
        //set the new scene onto the stage
        stage.setScene(newScene);
        stage.show();
        
        // set up the controller for the fxml file
        
        if (file.equals("Game.fxml")) {
        	GameController controller = loader.getController();
        	controller.getScene(stage);
        	controller.gameLoop();
        }
        else if (file.equals("Menu.fxml")) {
        	MenuController controller = loader.getController();
        	controller.getScene(stage);
        	controller.menuLoop();
        }
        else if (file.equals("End.fxml")) {
        	((EndController)loader.getController()).getScene(stage);
        }
        else if (file.equals("Victory.fxml")) {
        	VictoryController controller = loader.getController();
        	controller.getScene(stage);
        	controller.setScore(this.gsm);
        }else if (file.equals("Help.fxml")) {
        	((HelpController)loader.getController()).getScene(stage);
        }

	}
	
	// method to run the scene switch animation
	
	public void animate(){
		//animation timer to run animation
		canvas.toFront();
		
		new AnimationTimer() {
        	@Override
        	public void handle(long currentNanoTime) {
        		gc.setFill(new Color(0, 0, 0, alpha++ / 100.0));
        		gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        		if (alpha > 100) {
        			try {
						switchScene(newScene);
					} catch (IOException e) {
						e.printStackTrace();
					}
        			stop();
        		}
        	}
        }.start();
	}
	
	//**************************************************************************
	//
	//	 						GETTERS AND SETTERS
	//
	//**************************************************************************
	
	public String getNewScene() {return newScene;}
	public void setNewScene(String newScene) {this.newScene = newScene;}
}
