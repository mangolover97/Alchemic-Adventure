package application;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/*
 *  	Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Background
 * 
 * A class that can be instantiated. Each object of this 
 * class represents a background at a given time
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */

public class Background {
	
	//**************************************************************************
	//
	// 								ATTRIBUTES
	//
	//**************************************************************************
	
	GraphicsContext gc;
	Canvas canvas;
	
	private Image image;
	
	private Vector v, pos;
	private int scale;
	private Vector translate;
	
	
	//**************************************************************************
	//
	// 								CONSTRUCTOR
	//
	//**************************************************************************
	
	// background constructor
	
	public Background(GraphicsContext gc, Canvas canvas, Image image, int scale, double x, double y) {
		this.image = image;
		this.gc = gc;
		this.canvas = canvas;
		
		this.scale = scale;
		this.translate = new Vector(0, 0);
		
		this.pos = new Vector(x, y);
		this.v = new Vector(0.5, 0);
		
	}
	
	//**************************************************************************
	//
	// 								METHODS
	//
	//**************************************************************************
	
	// method to draw the background with the graphics context
	
	public void draw() {
		// start translation
		gc.translate(this.translate.getX(), this.translate.getY());
		
		// unscaled version
		if (scale == 1) {
		// image bleeds
		gc.drawImage(image, pos.getX() + canvas.getWidth(), 0);
		
		gc.drawImage(image, pos.getX() - canvas.getWidth(), 0);
		pos.setX(pos.getX() % canvas.getWidth());
		
		
		// draw image at location
		
		gc.drawImage(image, pos.getX(), 0);
		}
		
		// scaled version
		else {
			// bleed of image
			gc.drawImage(image, 
					100, 100,
					image.getWidth() - 100, image.getHeight() - 100,
					pos.getX() - 100 + canvas.getWidth(), - 100,
					(int)(image.getWidth() * 1.25), (int)(image.getHeight() * 1.25));
			
			gc.drawImage(image, 
					100, 100,
					image.getWidth() - 100, image.getHeight() - 100,
					pos.getX() - 100 - canvas.getWidth(), - 100,
					(int)(image.getWidth() * 1.25), (int)(image.getHeight() * 1.25));
			
			// for if player goes very long distance
			pos.setX(pos.getX() % canvas.getWidth());
			
			// center background
			gc.drawImage(image, 
					100, 100,
					image.getWidth() - 100, image.getHeight() - 100,
					pos.getX() - 100, - 100,
					(int)(image.getWidth() * 1.25), (int)(image.getHeight() * 1.25));
		}
		
		// end translation
		gc.translate(-this.translate.getX(), -this.translate.getY());
		this.move();
	}
	
	// method to move the background
	
	public void move() {
		this.pos = this.pos.add(this.v);
		this.pos.setX(this.pos.getX() / this.scale);
		this.pos.setY(this.pos.getY() / this.scale);
	}
	
	//**************************************************************************
	//
	// 							GETTERS AND SETTERS
	//
	//**************************************************************************
	
	public void setVector(double x, double y) {
		this.v.setX(x);
		this.v.setY(y);
	}
	
	public void setTranslate(double dx, double dy) {this.translate = new Vector(dx, dy);}
	public Image getImage() {return image;}
	public void setImage(Image image) {this.image = image;}
	public int getScale() {return scale;}
	public void setScale(int scale) {this.scale = scale;}
}
