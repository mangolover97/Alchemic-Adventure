package application;

import java.io.File;

//https://www.youtube.com/watch?v=9dzhgsVaiSo
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.AudioClip;
import javafx.scene.text.Font;
import javafx.fxml.FXMLLoader;

/*
 *  		Alchemic Adventure
 * 
 * Summary:
 * 
 * Alchemic adventure is a short and simple 2D 
 * platformer. The player can move left and right
 * and jump.
 * 
 * Class: Main
 * 
 * The class that is run to start the game.
 * 
 * Written by: Evan Howie
 * Assignment name: Final Project
 * Completed on: November 9th, 2020
 */


public class Main extends Application {
	// constants
	public static final int SCREENWIDTH = 1280;
	public static final int SCREENHEIGHT = 720;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			// initialization code for the game window
			
			primaryStage.setTitle("Alchemic Adventure");
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
			BorderPane root = (BorderPane)loader.load();
			Scene scene = new Scene(root,SCREENWIDTH,SCREENHEIGHT);
			Font.loadFont("/resources/Fonts/connection-iii-font/ConnectionIii-Rj3W.otf", 50);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			MenuController controller = loader.getController();
			//scene.getStylesheets().add("http://fonts.googleapis.com/css?family=Press-Start-2P");
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			controller.getScene(primaryStage);
			controller.menuLoop();
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
